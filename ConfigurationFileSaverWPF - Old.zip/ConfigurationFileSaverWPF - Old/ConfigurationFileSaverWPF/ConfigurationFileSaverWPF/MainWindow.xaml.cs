﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Configuration;
using System.Xml.Linq;

namespace ConfigurationFileSaverWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int fileCount = 0;
        // Commit this when produc
        String tempPath = (@"E:\Dev\MT\AppConfig.xml");

        public MainWindow()
        {
            InitializeComponent();
           
            String path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            if (File.Exists("appConfig.xml"))
            {
                //MessageBox.Show("Path: " + path);
                appConfigFilePath.Text = "App Config Path: "+path;
                // uncommit when in production
                tempPath = path + "\\AppConfig.xml";
            }
            else
            {
                MessageBox.Show("Set the App Config File.");
            }
 
            addNewFileSection();

        }

        public void deleteFile(object sender, RoutedEventArgs e)
        {

            //FileInfo fileInfo = new FileInfo(dlg.FileName);
            Button nowSender = (Button)sender;
            String btnText = nowSender.Name.Split('_')[1];
            XElement t = XElement.Load(tempPath);
            String deleteFilePath = t.Element("File_" + btnText).Value;

            //if (File.Exists(@"E:\Dev\MT\File_" + ((Button)sender).Name.Split('_')[1] + ".txt"))
            if (File.Exists(deleteFilePath))
            {
                File.Delete(deleteFilePath);
                t.Element("File_" + btnText).Value = "";
                t.Save(tempPath);
                MessageBox.Show("File Deleted: " + deleteFilePath, "File Delted");
            }
            else
            {
                MessageBox.Show("File Does not exist", "Not File Found Error");
            }
        }

        public void deleteFileSection(object sender, RoutedEventArgs e)
        {

            Button nowSender = (Button)sender;
            String btnText = nowSender.Name.Split('_')[1];

            StackPanel sk = (StackPanel)this.FindName("sk_" + btnText);
            sk.Visibility = Visibility.Collapsed;
        }

        public void renameFile(object sender, RoutedEventArgs e)
        {
            
            //FileInfo fileInfo = new FileInfo(dlg.FileName);
            Button nowSender = (Button)sender;
            String btnText = nowSender.Name.Split('_')[1];
            XElement t = XElement.Load(tempPath);
            String deleteFilePath = t.Element("File_" + btnText).Value;

            //if (File.Exists(@"E:\Dev\MT\File_" + ((Button)sender).Name.Split('_')[1] + ".txt"))
            if (File.Exists(deleteFilePath))
            {
                File.Delete(deleteFilePath);
                MessageBox.Show("File Deleted: " + deleteFilePath, "File Delted");
            }
            else
            {
                MessageBox.Show("File Does not exist", "Not File Found Error");
            }
        }
 
        public void saveFileDynamic(object sender, RoutedEventArgs e, string fileName)
        {
            //Button clickBtn = (Button)sender;
            //MessageBox.Show("Name: " + clickBtn.Name);

            // Configure save file dialog box
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            Button nowSender = (Button)sender;
            String btnText = nowSender.Name.Split('_')[1];
            dlg.FileName = fileName; // Default file name
            dlg.FileName = "File_"+btnText; // Default file name
            dlg.DefaultExt = ".txt"; // Default file extension
            dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                //TextBox file0 = (TextBox)sp0.Contro(fileName);
                TextBox textBox = (TextBox)this.FindName(fileName);

                StreamWriter sw = new StreamWriter(dlg.FileName);
                sw.Write(textBox.Text);

                FileInfo fileInfo = new FileInfo(dlg.FileName);
                XElement t = XElement.Load(tempPath);
                XElement file_element = t.Element("File_" + btnText);
                if (file_element == null)
                {
                    t.Add(new XElement("File_" + btnText, fileInfo.DirectoryName + "\\" + dlg.FileName));
                }
                else
                {
                    t.Element("File_" + btnText).Value = fileInfo.DirectoryName + "\\" + dlg.FileName;
                }
                //t.Element("File_" + btnText).Value = dlg.FileName;
                t.Save(tempPath);

                sw.Flush();
                sw.Close();
            }
                                
        }

        public void saveAllFiles(object sender, RoutedEventArgs e)
        {

            XElement t = XElement.Load(tempPath);

            for (int i = 0; i < 10; i++)
            {
                String tempFilePath = t.Element("File_" + i).Value;
                if (tempFilePath != null)
                {
                    TextBox tempTB = (TextBox)this.FindName("File_" + i);
                    if (tempTB.Text != null)
                    {
                        SaveFileDialog sf = new SaveFileDialog();
                    }

                }
            }


            //Button clickBtn = (Button)sender;
            //MessageBox.Show("Name: " + clickBtn.Name);

            // Configure save file dialog box
            //Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            //Button nowSender = (Button)sender;
            //String btnText = nowSender.Name.Split('_')[1];
            //dlg.FileName = fileName; // Default file name
            //dlg.FileName = "File_" + btnText; // Default file name
            //dlg.DefaultExt = ".txt"; // Default file extension
            //dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            //// Show save file dialog box
            //Nullable<bool> result = dlg.ShowDialog();

            //// Process save file dialog box results
            //if (result == true)
            //{
            //    // Save document
            //    //TextBox file0 = (TextBox)sp0.Contro(fileName);
            //    TextBox textBox = (TextBox)this.FindName(fileName);

            //    StreamWriter sw = new StreamWriter(dlg.FileName);
            //    sw.Write(textBox.Text);

            //    FileInfo fileInfo = new FileInfo(dlg.FileName);
            //    t = XElement.Load(tempPath);
            //    //t.Element("File_" + btnText).Value = fileInfo.DirectoryName + "\\" + dlg.FileName;
            //    t.Element("File_" + btnText).Value = dlg.FileName;
            //    t.Save(tempPath);

            //    sw.Flush();
            //    sw.Close();
            //}

        }

        public void loadAllFiles(object sender, RoutedEventArgs e)
        {

            XElement t = XElement.Load(tempPath);

            for (int i = 0; i < 10; i++)
            {
                String tempFilePath = t.Element("File_" + i).Value;
                if (tempFilePath != null)
                {
                    TextBox tempTB = (TextBox)this.FindName("File_" + i);
                    if (tempTB.Text != null)
                    {
                        SaveFileDialog sf = new SaveFileDialog();
                    }

                }
            }


            //Button clickBtn = (Button)sender;
            //MessageBox.Show("Name: " + clickBtn.Name);

            // Configure save file dialog box
            //Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            //Button nowSender = (Button)sender;
            //String btnText = nowSender.Name.Split('_')[1];
            //dlg.FileName = fileName; // Default file name
            //dlg.FileName = "File_" + btnText; // Default file name
            //dlg.DefaultExt = ".txt"; // Default file extension
            //dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            //// Show save file dialog box
            //Nullable<bool> result = dlg.ShowDialog();

            //// Process save file dialog box results
            //if (result == true)
            //{
            //    // Save document
            //    //TextBox file0 = (TextBox)sp0.Contro(fileName);
            //    TextBox textBox = (TextBox)this.FindName(fileName);

            //    StreamWriter sw = new StreamWriter(dlg.FileName);
            //    sw.Write(textBox.Text);

            //    FileInfo fileInfo = new FileInfo(dlg.FileName);
            //    t = XElement.Load(tempPath);
            //    //t.Element("File_" + btnText).Value = fileInfo.DirectoryName + "\\" + dlg.FileName;
            //    t.Element("File_" + btnText).Value = dlg.FileName;
            //    t.Save(tempPath);

            //    sw.Flush();
            //    sw.Close();
            //}

        }

        public void addNewFileSection()
        {
            //int fileCount = 0;
            fileCount++;

            StackPanel sk = new StackPanel();
            sk.Orientation = Orientation.Horizontal;
            RegisterName("sk_" + fileCount, sk);
            sk.Name = "sk_" + fileCount;
            RegisterName("sk_" + fileCount, sk);

            TextBox tb1 = new TextBox();
            tb1.Width = 300;
            tb1.Padding = new Thickness(5, 5, 5, 5);
            tb1.Margin = new Thickness(5, 5, 5, 5);
            RegisterName("File_" + fileCount, tb1);
            tb1.Name = "File_" + fileCount;

            TextBox textBlock1 = new TextBox();
            textBlock1.Width = 60;
            textBlock1.Padding = new Thickness(5, 5, 5, 5);
            textBlock1.Margin = new Thickness(5, 5, 5, 5);
            textBlock1.Text = "File_" + fileCount + ".txt";
            RegisterName("FileNameBlock_" + fileCount, textBlock1);
            textBlock1.Name = "FileNameBlock_" + fileCount;

            Button renameBtn = new Button();
            renameBtn.Width = 60;
            renameBtn.Padding = new Thickness(5, 5, 5, 5);
            renameBtn.Margin = new Thickness(5, 5, 5, 5);
            renameBtn.Content = "Rename";
            RegisterName("renameBtn_" + fileCount, renameBtn);
            renameBtn.Name = "renameBtn_" + fileCount;
            renameBtn.Click += delegate(object sender, RoutedEventArgs e)
            {
                renameFile(sender, e);
            };

            Button saveBtn = new Button();
            saveBtn.Width = 60;
            saveBtn.Padding = new Thickness(5, 5, 5, 5);
            saveBtn.Margin = new Thickness(5, 5, 5, 5);
            saveBtn.Content = "Save";
            RegisterName("saveBtn_" + fileCount, saveBtn);
            saveBtn.Name = "saveBtn_" + fileCount;
            saveBtn.Click += delegate(object sender, RoutedEventArgs e) { saveFileDynamic(sender, e, "File_" + fileCount); };

            Button deleteBtn = new Button();
            deleteBtn.Width = 60;
            deleteBtn.Padding = new Thickness(5, 5, 5, 5);
            deleteBtn.Margin = new Thickness(5, 5, 5, 5);
            RegisterName("deleteBtn_" + fileCount, deleteBtn);
            deleteBtn.Name = "saveBtn_" + fileCount;
            deleteBtn.Content = "Delete";
            //deleteBtn.Click += delegate(object sender, RoutedEventArgs e) { deleteFile(sender, e); };
            deleteBtn.Click += delegate(object sender, RoutedEventArgs e) { deleteFileSection(sender, e); };


            sk.Children.Add(tb1);
            sk.Children.Add(textBlock1);
            sk.Children.Add(renameBtn);
            sk.Children.Add(saveBtn);
            sk.Children.Add(deleteBtn);

            this.mainPanel2.Children.Add(sk);

        }

        #region Old Section
      
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            MessageBox.Show("this is test:" + btn.Name, "Test");
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            //saveFile();
        }

        private void create_File_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text file (*.txt)|*.txt|C# file (*.cs)|*.cs";

            if (saveFileDialog.ShowDialog() == true)
                File.WriteAllText(saveFileDialog.FileName, File_0.Text);
           
        }

        private void Button_Click_App_Config_Save(object sender, RoutedEventArgs e)
        {
            XDocument srcTree = new XDocument(
               new XComment("This is a comment"),
               new XElement("Root",
                   new XElement("Child1", "data1"),
                   new XElement("Child2", "data2"),
                   new XElement("Child3", "data3"),
                   new XElement("Child2", "data4"),
                   new XElement("Info5", "info5"),
                   new XElement("Info6", "info6"),
                   new XElement("Info7", "info7"),
                   new XElement("Info8", "info8")
                   )
               );
            srcTree.Declaration = new XDeclaration("1.0", "utf-8", "true");

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "XML-File | *.xml";
            saveFileDialog.FileName = "AppConfig";

            // Show save file dialog box
            Nullable<bool> result = saveFileDialog.ShowDialog();

            if (result == true)
            {
                srcTree.Save(saveFileDialog.FileName);
            }
        }

      

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {

        }

         private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btnN = new Button();
            btnN.Content = "New Button";
            btnN.Width = 40;
            btnN.Height = 20;
            
            this.mainPanel.Children.Add(btnN);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {

        }

        private void btnMe_Click(object sender, RoutedEventArgs e)
        {
            addNewFileSection();
        }

        public void saveFile(object sender, RoutedEventArgs e)
        {
            //System.IO.StreamWriter file = new System.IO.StreamWriter("testFile.txt");
            //file.Write("Allah O Akbar");
            //file.Close();

            // Configure save file dialog box
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog();
            dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".txt"; // Default file extension
            dlg.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            // Show save file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process save file dialog box results
            if (result == true)
            {
                // Save document
                string filename = dlg.FileName;
            }
        }

        private void DrawCircleButton_Click(object sender, RoutedEventArgs e)
        {


        }

        #endregion

        }
}
